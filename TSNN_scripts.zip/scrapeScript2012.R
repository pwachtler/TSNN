scrapeScript2012<-function(url,urlNum)
{
  
  ## script for scraping web data
  
  
  ## loading functions
  source("ld.data.R")
  source("numFields.R")
  source("n.Locs2013.R")
  
  
  ## loading webpage into object named "data"
  ##data<-ld.data("www.tsnn.com/toplists-us")
  data<-ld.data(url)
  
  ## store number of list items from webpage in an object named list.Fields
  list.Fields<-numFields(data[[1]])
  
  ## store number of text fields within each list item in an object named text.Fields
  text.Fields<-(numFields(data[[1]][[1]]))
  
  
  
  ##DATA PARSING
  
  
  
  ##Initialize all variables
  Rank<-0
  ConfName<-""
  ConfDescrip<-""
  Organizer<-""
  NumExhibitors<-0
  NumAttendees<-0
  NumExhibPersonnel<-0
  FromDate<-0
  ToDate<-0
  DaysElapsed<-0
  ConfCenterName<-0
  city<-""
  ConfSqFoot<-0
  
  trim <- function (x) gsub("^\\s+|\\s+$", "", x)
  
  
  ##1st List Itetestms
  ##Rank
  ##Store in vector named rank
  ##Rank should be an integer; use as.integer to convert from characters to integers
  Rank<-as.integer(data[[1]][[1]])
  
  
  ##2nd List Items
  
  ##Store location of "\n" for each item in the 2nd list
  
  
  ##Conference Name
  ##Store in vector named ConfName
  ##Need a for loop to loop through each sublist item
  event<-data[[1]][[2]]
  ndata<-matrix(0,text.Fields,11)
  
  for (i in 1:text.Fields)
  {ConfName[i]<-substr(event[[i]],1,regexpr("\n",event[[i]])[1]-1)
  }
  
  ##For all other text fields in the 2nd sub-list, retrieve table with location of all "\n" values
  
  ndata<-n.Locs2013(event,urlNum,text.Fields)
  
  ##Conference Description
  ##Second block of text between first and second "\n"
  
  nSet<-1 ##setting the offset for n for this specific block of text
  
  for (i in 1:text.Fields)
    
    ##Set condition for Husker Harvest Days - there is an extra "\n" in their text for some reason  
  {  
      if((urlNum==1 && i==11) || (urlNum==5 && i==1) || (urlNum==8 && i==5) || (urlNum==13 && i==5))
      {
        ConfDescrip[i]<-""
        }
       
      else{
      ConfDescrip[i]<-substr(event[[i]],ndata[i,nSet]+2, ndata[i,nSet+1]-1)
      }
    
  }
  
  
  #Organizer
  ##Text between 6th and 7th “/n”
  
  nSet<-6 ##setting the offset for n for this specific block of text
  
  for (i in 1:text.Fields)
    
    ##Set condition where formatting is different - there are extra "\n"s for some reason  
    {  
    if((urlNum==1 && i==11) || (urlNum==5 && i==1) || (urlNum==8 && i==5) || (urlNum==13 && i==5))
          {Organizer[i]<-substr(event[[i]],ndata[i,nSet-1]+12, ndata[i,nSet]-1)
          }
    
              else if(urlNum==7 && i ==10)
              {Organizer[i]<-substr(event[[i]],ndata[i,nSet+3]+12, ndata[i,nSet+4]-1)
                
              } 
    
            else{
            Organizer[i]<-substr(event[[i]],ndata[i,nSet]+12, ndata[i,nSet+1]-1)
                 }
     }
  
  
  #Number of Exhibitors
  ##Text between 7th and 8th “/n”
  
  nSet<-7 ##setting the offset for n for this specific block of text
  NumExText<-""
  
  for (i in 1:text.Fields)
    
    ##Set condition for Husker Harvest Days - there is an extra "\n" in their text for some reason  
    {
    if((urlNum==1 && i==11) || (urlNum==5 && i==1) || (urlNum==8 && i==5) || (urlNum==13 && i==5))
        {NumExText<-substr(event[[i]],ndata[i,nSet-1]+15, ndata[i,nSet]-1)
        ##print(ndata[i,])
        ##print(substr(event[[i]],ndata[i,nSet+1]+15, ndata[i,nSet+1]))
        NumExhibitors[i]<-as.numeric(gsub(",","",NumExText))}
        
        else if(urlNum==7 && i ==10)
        {NumExText<-substr(event[[i]],ndata[i,nSet+3]+15, ndata[i,nSet+4]-1)
        NumExhibitors[i]<-as.numeric(gsub(",","",NumExText))}
    
          else{
              NumExText<-substr(event[[i]],ndata[i,nSet]+15, ndata[i,nSet+1]-1)
              NumExhibitors[i]<-as.numeric(gsub(",","",NumExText))}
          }
  
  
  #Number of Attendees
  ##Text between 8th and 9th “/n”
  
  nSet<-8 ##setting the offset for n for this specific block of text
  
  for (i in 1:text.Fields)
    
     
      {  if((urlNum==1 && i==11) || (urlNum==5 && i==1) || (urlNum==8 && i==5) || (urlNum==13 && i==5))
            {NumAtText<-substr(event[[i]],ndata[i,nSet-1]+14, nchar(event[[i]]))
            NumAttendees[i]<-as.numeric(gsub(",","",NumAtText))}
        
         else
          {NumAtText<-substr(event[[i]],ndata[i,nSet]+14, nchar(event[[i]]))
           NumAttendees[i]<-as.numeric(gsub(",","",NumAtText))}
      }
  
  
  # #Number of Exhibitor Personnel
  # ##Text between 9th and end “/n”
  # 
  # nSet<-9 ##setting the offset for n for this specific block of text
  # 
  # for (i in 1:text.Fields)
  #   
  #   ##Set condition for Husker Harvest Days - there is an extra "\n" in their text for some reason  
  # {  if((urlNum==1 && i == 3)) ##|| (urlNum==4 && i == 6))
  # {NumExPersText<-substr(event[[i]],ndata[i,nSet+1]+24, nchar(event)[i])
  # NumExhibPersonnel[i]<-as.numeric(gsub(",","",NumExPersText))}
  #   
  #   else{
  #     NumExPersText<-substr(event[[i]],ndata[i,nSet]+24, nchar(event)[i])
  #     NumExhibPersonnel[i]<-as.numeric(gsub(",","",NumExPersText))}
  # }
  
  
  
  
  ##3rd List Items
  
  ##Date From
  
  dates<-data[[1]][[3]]
  ##First Date
  ##NEED A LOOP
  
  
  for (i in 1:text.Fields)
  {  FromDate[i]<-substr(dates[[i]],1,10)}
  FromDate<-as.Date(FromDate,"%m/%d/%Y")
  
  
  ##Date To
  ##Second Date
  ##NEED A LOOP
  
  
  
  for (i in 1:text.Fields)
  {  ToDate[i]<-substr(dates[[i]],15,nchar(dates[[i]]))}
  ToDate<-as.Date(ToDate,"%m/%d/%Y")
  
  
  ##Days Elapsed
  ##Days between dates
  
  
  for (i in 1:text.Fields)
  {  DaysElapsed[i]<-ToDate[i]-FromDate[i]}
  
  
  
  ##4th List Items
  
  ##Conference Info
  
  ConfInfo<-data[[1]][[4]]
  
  for (i in 1:text.Fields)
  {ConfCenterName[i]<-substr(ConfInfo[[i]],1,regexpr("\n",ConfInfo[[i]])[1]-1)
  }
  
  ##city
  
  for (i in 1:text.Fields)
  { holder<-regexpr("\n",ConfInfo[[i]])[1]+1
  holdSubstr<-substr(ConfInfo[[i]],holder,nchar(ConfInfo[[i]])[1])
  city[i]<-trim(substr(ConfInfo[[i]],holder,holder+regexpr("\n",holdSubstr)-2))
  }
  
  ##Square Footage
  
  for (i in 1:text.Fields)
  {ConfSqFootText<-substr(ConfInfo[[i]],regexpr("NSF:",ConfInfo[[i]])[1]+5,nchar(ConfInfo[[i]]))
  ConfSqFoot[i]<-as.numeric(gsub(",","",ConfSqFootText))
  }
  
  ##create confYear column
      confYear<-""
      for (i in seq_along(ConfName))
      {confYear[i]<-"2012"}
  
  ##combine into final output table
  scrapeTable<-cbind.data.frame(confYear,Rank, ConfName, ConfDescrip, Organizer, NumExhibitors, NumAttendees,NumExhibPersonnel,FromDate,ToDate,DaysElapsed,ConfCenterName,city, ConfSqFoot)
  ##scrapeTable<-cbind.data.frame(Rank, ConfName, ConfDescrip, Organizer, NumExhibitors, NumAttendees,FromDate,ToDate,DaysElapsed,ConfCenterName,city, ConfSqFoot)
  return (scrapeTable)
  
}