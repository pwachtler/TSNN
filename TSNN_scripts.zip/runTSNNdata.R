source("2012TSNN.R")
source("2013TSNN.R")
source("2014TSNN.R")

year12<-TSNN2012()
year13<-TSNN2013()
year14<-TSNN2014()

final.table<-rbind.data.frame(year12,year13,year14)
write.csv(final.table,"allYears.csv")