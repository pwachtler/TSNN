TSNN2014<-function()
{
  
  ##Script for compiling TSNN 2014 Top 250 US Trade Shows Data

## turn off potential NA warnings
oldw<-getOption("warn")
options(warn=-1)

    ##compile all site URLs
        
        urlStore<-vector(length=26)
        urlNum<-vector(length=26)
        for (i in seq_along(urlStore))
        {
          if(i==1)
            {urlStore[i]<-"www.tsnn.com/toplists-us"}
              else{
                 r<-paste("http://www.tsnn.com/toplists-us?ds_name=&field_datasite_venue_name_value=&field_datasite_venue_city_value=&field_datasite_event_date_value_1[value]=&page=",i-1,sep="")
                 urlStore[i]<-r
              }
          urlNum[i]<-i
        }
        
        
        ##create a loop to send urlStore variables to the scrapeScript function
        ##parameters are url
        source("scrapeScript.R")
        
        count<-0
        df<-data.frame()
        
        for (i in seq_along(urlStore))
        ##for (i in 1:2)  
        {
            
            df<-rbind(df,scrapeScript(urlStore[i],urlNum[i]))
        }
        
        options(warn=oldw)## turn back on warnings
        
        write.csv(df,"2014 TSNN Dataset.csv")
        
        ##need to create an index that increases to make sure that new data is appended to the bottom
        ##of row

        ##need to pass the count through to scrapeScript to make sure the indexes increase
        
        
        ##create final data frame table with cbind at the end
        ##then export to a .csv
        
        return(df)       
}