library(httr)
library(curl)
library(XML)
ld.data<-function(url){
  ## scrapes text from url
  ## make sure to store returned values in an object
  urldata<-GET(url)
  data<-readHTMLTable(rawToChar(urldata$content),stringsAsFactors=FALSE,header=TRUE)
  
}
  