numFields<-function(list)
{
    ##function outputs the number of data fields that exist in a list or sublist
    length(list)
}