n.Locs<-function(funcText,urlNum,numLists=text.Fields)
{ ## This function returns the locations of "\n" within the text as a table
  ## For some reason, the 3rd item in the list - Husker Harvest Days, has an extra /n so we need to account for that
      
  ##find number of "\n"s in a text field to set the Table column length properly
  greg<-as.vector(gregexpr('\n',funcText[[1]]))[[1]]

  ##initialize storage matrix
  nTable<-matrix(0,numLists,10)

  for (i in 1:numLists)
    {greg<-as.vector(gregexpr('\n',funcText[[i]])[[1]])
    
        for (j in 1:10)
        {
          if((!(urlNum==1)&&!(i==3))&&j==10)
          {nTable[i,j]<-0}
          else{nTable[i,j]<-greg[j]}
        }
     }
  
  return(nTable)
  
}