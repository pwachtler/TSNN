TSNN2012<-function()
{

##Script for compiling TSNN 2014 Top 250 US Trade Shows Data

library(zoo)

## turn off potential NA warnings
oldw<-getOption("warn")
options(warn=-1)

    ##compile all site URLs
        
        urlStore<-vector(length=18)
        urlNum<-vector(length=18)
        for (i in seq_along(urlStore))
        {
          if(i==1)
            {urlStore[i]<-"http://www.tsnn.com/toplists-us-2012"}
              else{
                 r<-paste("http://www.tsnn.com/toplists-us-2012?ds_name=&field_datasite_venue_name_value=&field_datasite_venue_city_value=&field_datasite_event_date_value_1[value]=&page=",i-1,sep="")
                 urlStore[i]<-r
              }
          urlNum[i]<-i
        }
        
        
        ##create a loop to send urlStore variables to the scrapeScript function
        ##parameters are url
        source("scrapeScript2012.R")
        
        
        ##count<-0
        df<-data.frame()
        df.new<-data.frame()
        
        for (i in seq_along(urlStore))
        
        {
            
            df<-rbind(df,scrapeScript2012(urlStore[i],urlNum[i]))
        }
        
       
        # date format is getting messed up here
        for(i in 1:nrow(df))
          {if (!(i%%2 == 0))
          {
            for (j in 1:ncol(df))
             {df.new[i,j]<-df[i,j]}
          }}
        
       
        
        df.new[,9]<-as.Date(df.new[,9])
        df.new[,10]<-as.Date(df.new[,10])
        
        
        
        options(warn=oldw)## turn back on warnings
        
        
        df.new<-na.omit(df.new)
        
        
        rownames(df.new)<-1:nrow(df.new)
        colnames(df.new)<-c("confYear","Rank", "ConfName", "ConfDescrip", "Organizer", "NumExhibitors", "NumAttendees","NumExhibPersonnel","FromDate","ToDate","DaysElapsed","ConfCenterName","city", "ConfSqFoot")
        
        
        write.csv(df.new,"2012 TSNN Dataset.csv")
        
        
        return(df.new)
        
}