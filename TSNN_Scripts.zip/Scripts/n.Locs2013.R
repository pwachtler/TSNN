n.Locs2013<-function(funcText,urlNum,numLists=text.Fields)
{ ## This function returns the locations of "\n" within the text as a table
  ## For some reason, the 3rd item in the list - Husker Harvest Days, has an extra /n so we need to account for that
  
  ##find number of "\n"s in a text field to set the Table column length properly
  greg<-as.vector(gregexpr('\n',funcText[[1]]))[[1]]
  
  ##initialize storage matrix
  nTable<-matrix(0,numLists,11)
  
  for (i in 1:numLists)
  {greg<-gregexpr('\n',funcText[[i]])[[1]]
  
  for (j in 1:11)
  {
    if((!(urlNum==7)&&!(i==10))&&(!(urlNum==11)&&!(i==1))&&(!(urlNum==19)&&!(i==5))&&(j>=9))
    {nTable[i,j]<-0}
    
    else{nTable[i,j]<-greg[j]}
  }
  }
  
  return(nTable)
  
}